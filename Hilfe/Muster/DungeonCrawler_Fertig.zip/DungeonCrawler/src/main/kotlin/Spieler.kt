class Spieler {
    var x: Int
    var y: Int
    var leben: Int = 6
    var schaden: Int = 1
    var istTot: Boolean = false
    var geld: Int = 0

    constructor(x: Int, y: Int) {
        this.x = x
        this.y = y
    }

    fun istAufPosition(x: Int, y: Int): Boolean {
        var istDasMeinePosition = this.x == x && this.y == y
        return istDasMeinePosition
    }

    fun setzePosition(x: Int, y: Int) {
        this.x = x
        this.y = y
    }

    fun greifeAn(gegner: Gegner) {
        gegner.erhalteSchaden(schaden)
    }

    fun bewege(x: Int, y: Int, welt: ZeilenWelt) {
        if (welt.istBegehbar(x, y)) {
            this.x = x
            this.y = y
        }
    }

    fun erhalteGeld() {
        geld = geld + 1
    }

    fun erhalteSchaden(menge: Int) {
        leben = leben - menge
        if (leben <= 0) {
            istTot = true
        }
    }

    fun gegnerInReichweite(gegner: Gegner): Boolean {
        if (gegner.x == x && (gegner.y  == y - 1|| gegner.y == y + 1)) {
            return true
        } else if (gegner.y == y && (gegner.x == x - 1 || gegner.x == x + 1)) {
            return true
        } else {
            return false
        }
    }
}