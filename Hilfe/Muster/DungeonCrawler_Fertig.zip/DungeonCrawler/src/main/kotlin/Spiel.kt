/**
 * Die Klasse Spiel dient der Verwaltung des laufenden Spiels. In ihr werden alle Elemente des Spiels initialisiert
 * und miteinander in Verknüpfung gesetzt. In ihr läuft die Spielschleife ab, d.h. eine potenzielle Endlosschleife
 * die das Spiel nur beendet wenn der Spieler das Spiel beendet oder gewonnen/verloren hat.
 */
class Spiel {
    var spielLaeuft: Boolean = false
    var stift = Stift()
    var welt: ZeilenWelt

    var spieler: Spieler
    var gegner1: Gegner
    var gegner2: Gegner

    /**
     * Das Einlesen der Karte wird vorerst weggelassen
     * Stattdessen wird eine Karte als Text vorgegeben
     * Durch die Verwendung von drei Anführungszeichen kann ein mehrzeiliger String im Code definiert werden.
     */
    constructor() {
        var zeilen = """
        ####################
        #....~.............#
        #....~....1....a...#
        #...c~..2......b...#
        #..~~~~~~..........#
        #...........X......#
        #################### 
    """.trimIndent()

        spieler = Spieler(0,0)
        gegner1 = Gegner(0,0)
        gegner2 = Gegner(0,0)
        var muenze1 = Muenze(0,0)
        var muenze2 = Muenze(0,0)
        var muenze3 = Muenze(0,0)

        welt = ZeilenWelt(zeilen, spieler, gegner1, gegner2, muenze1, muenze2, muenze3)
    }

    /**
     * Diese Funktion sollte auf einem Objekt der Klasse Spiel aufgerufen werden, um das Spiel zu starten.
     * Die While-Schleife erzeugt solange neue Züge, bis der Boolean spielLaeuft auf false gesetzt wird.
     * Sinnvolle Gründe hierfür können der Abbruch des Spiels sein (durch Spielereingabe) oder weil der Spieler
     * gewonnen oder verloren hat.
     */
    fun starteSpiel() {
        spielLaeuft = true

        while (spielLaeuft) {
            welt.zeichneWelt(stift)
            stift.schreibe("Was möchtest du tun:")
            stift.neueZeile()
            verarbeiteSpielerEingabe()

            if (spieler.geld == 3) {
                stift.schreibeGelb("SIEG")
                spielLaeuft = false
            } else {
                verarbeiteGegnerAktionen()

                if (spieler.istTot) {
                    stift.schreibeRot("DU BIST BESIEGT")
                    spielLaeuft = false
                } else {
                    beendeZug()
                }
            }
        }
    }

    /**
     * In dieser Funktion wird der Zug des Spielers ausgeführt.
     */
    fun verarbeiteSpielerEingabe() {
        stift.schreibe("> ")
        var eingabe = readln()

        if (eingabe == "ende") {
            spielLaeuft = false
        } else if (eingabe == "w") {
            spieler.bewege(spieler.x, spieler.y - 1, welt)
        } else if (eingabe == "s") {
            spieler.bewege(spieler.x, spieler.y + 1, welt)
        } else if (eingabe == "a") {
            spieler.bewege(spieler.x - 1, spieler.y, welt)
        } else if (eingabe == "d") {
            spieler.bewege(spieler.x + 1, spieler.y, welt)
        } else {
            stift.schreibe("Unbekannte Eingabe! Schade!")
            stift.neueZeile()
        }

        welt.sammleMuenzeEin(spieler)

        if (spieler.gegnerInReichweite(gegner1)) {
            spieler.greifeAn(gegner1)
        } else if (spieler.gegnerInReichweite(gegner2)) {
            spieler.greifeAn(gegner2)
        }
    }

    /**
     * In dieser Funktion wird der Zug des Gegners ausgeführt.
     */
    fun verarbeiteGegnerAktionen() {
        if (!gegner1.istTot) {
            gegner1.bewege(welt)
            if (gegner1.spielerInReichweite(spieler)) {
                gegner1.greifeAn(spieler)
            }
        }

        if (!gegner2.istTot) {
            gegner2.bewege(welt)
            if (gegner2.spielerInReichweite(spieler)) {
                gegner2.greifeAn(spieler)
            }
        }
    }

    /**
     * Diese Funktion beendet den aktuellen Zug. Sie sollte um mögliche Ereignisse erweitert werden,
     * die am Ende des Zugs vorliegen könnten.
     */
    fun beendeZug() {
        stift.neueZeile()
        stift.schreibe("-- ENDE DES ZUGS --")
        stift.neueZeile()
    }
}