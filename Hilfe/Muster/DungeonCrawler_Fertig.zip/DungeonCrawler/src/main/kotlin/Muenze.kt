class Muenze {
    var x: Int
    var y: Int
    var istEingesammelt: Boolean

    constructor(x: Int, y: Int) {
        this.x = x
        this.y = y
        istEingesammelt = false
    }

    fun istAufPositionUndVorhanden(x: Int, y: Int): Boolean {
        var istDasMeinePosition = this.x == x && this.y == y

        if (!istDasMeinePosition) {
            return false
        } else if (istEingesammelt) {
            return false
        } else {
            return true
        }
    }

    fun setzePosition(x: Int, y: Int) {
        this.x = x
        this.y = y
    }

    fun sammleEin() {
        istEingesammelt = true
    }
}