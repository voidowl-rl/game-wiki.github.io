import kotlin.random.Random
import kotlin.random.nextUInt

class Gegner {
    var x: Int
    var y: Int
    var leben: Int = 2
    var schaden: Int = 2
    var istTot = false

    constructor(x: Int, y: Int) {
        this.x = x
        this.y = y
    }

    fun istAufPositionUndLebt(x: Int, y: Int): Boolean {
        var istDasMeinePosition = this.x == x && this.y == y

        if (!istDasMeinePosition) {
            return false
        } else if (istTot) {
            return false
        } else {
            return true
        }
    }

    fun setzePosition(x: Int, y: Int) {
        this.x = x
        this.y = y
    }

    fun bewege(welt: ZeilenWelt) {
        var richtung = Random.nextInt(0, 4)

        if (richtung == 0) {
            var neuesY = y-1
            if (welt.istBegehbar(x, neuesY)) {
                y = neuesY
            }
        } else if (richtung == 1) {
            var neuesY = y+1;
            if (welt.istBegehbar(x, neuesY)) {
                y = neuesY
            }
        } else if (richtung == 2) {
            var neuesX = x-1;
            if (welt.istBegehbar(neuesX, y)) {
                x = neuesX
            }
        } else if (richtung == 3) {
            var neuesX = x+1;
            if (welt.istBegehbar(neuesX, y)) {
                x = neuesX
            }
        }
    }

    fun greifeAn(spieler: Spieler) {
        spieler.erhalteSchaden(schaden)
    }

    fun erhalteSchaden(menge: Int) {
        leben = leben - menge
        if (leben <= 0) {
            istTot = true
        }
    }

    fun spielerInReichweite(spieler: Spieler): Boolean {
        if (spieler.x == x && (spieler.y  == y - 1|| spieler.y == y + 1)) {
            return true
        } else if (spieler.y == y && (spieler.x == x - 1 || spieler.x == x + 1)) {
            return true
        } else {
            return false
        }
    }
}