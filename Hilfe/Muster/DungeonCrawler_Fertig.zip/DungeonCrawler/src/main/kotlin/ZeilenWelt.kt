/**
 * Die Zeilenwelt verwaltet die unbeweglichen Teile der Welt und hat außerdem zusätzliche Funktionen, um
 * zu überprüfen, ob ein Feld begehbar ist oder nicht. Eine Welt besteht immer aus einer exakt
 * 20x7 großen Welt, einem Spieler und zwei Gegnern.
 */
class ZeilenWelt {
    var statischeWelt: String

    var spieler: Spieler
    var gegner1: Gegner
    var gegner2: Gegner

    var muenze1: Muenze
    var muenze2: Muenze
    var muenze3: Muenze

    constructor(alleZeilen: String, spieler: Spieler, gegner1: Gegner, gegner2: Gegner, muenze1: Muenze, muenze2: Muenze, muenze3: Muenze) {
        this.spieler = spieler
        this.gegner1 = gegner1
        this.gegner2 = gegner2
        this.muenze1 = muenze1
        this.muenze2 = muenze2
        this.muenze3 = muenze3

        var weltDaten = ""

        // Diese Schleife wird genau so oft ausgeführt, wird der String Zeilen Zeichen hat.
        // Der aktuelle Wert ist im Schleifenblock in der Variable position verfügbar.
        for (position in 0..alleZeilen.length - 1) {
            // Über die Syntax zeilen[<Variable oder Wert>] kann auf ein einzelnes Zeichen
            // eines Strings zugegriffen werden.
            // Der Variablentyp eines Zeichens wird CHAR genannt.
            var aktuellesZeichen: Char = alleZeilen[position]

            // Vergiss nicht, Gegner, Spieler und Münzen in eigene Objekte zu überführen und auf der Karte
            // an ihrer statt einfach ein leeres Feld zu platzieren (.).
            if (aktuellesZeichen == 'a') {
                // Erstelle die Goldmuenze
                muenze1.setzePosition(textPositionZuXKoordinate(position), textPositionZuYKoordiante(position))
                // Ersetze die Muenze auf unserer STATISCHEN Karte
                weltDaten = weltDaten + '.'
            } else if (aktuellesZeichen == 'b') {
                muenze2.setzePosition(textPositionZuXKoordinate(position), textPositionZuYKoordiante(position))
                weltDaten = weltDaten + '.'
            } else if (aktuellesZeichen == 'c') {
                muenze3.setzePosition(textPositionZuXKoordinate(position), textPositionZuYKoordiante(position))
                weltDaten = weltDaten + '.'
            } else if (aktuellesZeichen == '1') {
                gegner1.setzePosition(textPositionZuXKoordinate(position), textPositionZuYKoordiante(position))
                weltDaten = weltDaten + '.'
            } else if (aktuellesZeichen == '2') {
                gegner2.setzePosition(textPositionZuXKoordinate(position), textPositionZuYKoordiante(position))
                weltDaten = weltDaten + '.'
            } else if (aktuellesZeichen == 'X') {
                spieler.setzePosition(textPositionZuXKoordinate(position), textPositionZuYKoordiante(position))
                weltDaten = weltDaten + '.'
            } else {
                weltDaten = weltDaten + aktuellesZeichen
            }
        }

        statischeWelt = weltDaten
    }

    /**
     * Diese Funktion gibt die Welt auf der Konsole auf. Für jedes Feld wird vor der Ausgabe überprüft,
     * ob nicht stattdessen ein Gegner, eine Münze oder ein Spieler dargestellt werden muss.
     */
    fun zeichneWelt(stift: Stift) {
        for (position in 0..statischeWelt.length - 1) {
            var x = textPositionZuXKoordinate(position)
            var y = textPositionZuYKoordiante(position)

            // Zeichne die statische Karte nur, wenn dort kein dynamisches Element liegt
            if (gegner1.istAufPositionUndLebt(x, y)) {
                stift.schreibe('1')
            } else if (gegner2.istAufPositionUndLebt(x, y)) {
                stift.schreibe('2')
            } else if (spieler.istAufPosition(x, y)) {
                stift.schreibe('X')
            } else if (muenze1.istAufPositionUndVorhanden(x, y) || muenze2.istAufPositionUndVorhanden(x,y) || muenze3.istAufPositionUndVorhanden(x,y)) {
                stift.schreibe('o')
            } else {
                stift.schreibe(statischeWelt[position])
            }
        }
        stift.neueZeile()
    }

    /**
     * Diese Funktion überprüft, ob ein Feld mit den Koordinaten x und y begehbar ist, oder ob es blockiert ist.
     */
    fun istBegehbar(x: Int, y: Int): Boolean {
        if (x > 19 || x < 0 || y < 0 || y > 6) {
            return false
        }

        if (gegner1.istAufPositionUndLebt(x,y) || gegner2.istAufPositionUndLebt(x,y) || spieler.istAufPosition(x,y)) {
            return false
        }

        var position = koordinateZuTextPosition(x, y)

        if (statischeWelt[position] == '#' || statischeWelt[position] == '~') {
            return false
        }

        return true
    }

    fun sammleMuenzeEin(spieler: Spieler) {
        if (muenze1.istAufPositionUndVorhanden(spieler.x, spieler.y)) {
            spieler.erhalteGeld()
            muenze1.sammleEin()
        } else if (muenze2.istAufPositionUndVorhanden(spieler.x, spieler.y)) {
            spieler.erhalteGeld()
            muenze2.sammleEin()
        } else if (muenze3.istAufPositionUndVorhanden(spieler.x, spieler.y)) {
            spieler.erhalteGeld()
            muenze3.sammleEin()
        }
    }

    fun textPositionZuXKoordinate(textPosition: Int): Int {
        var x = textPosition % 21
        return x
    }

    fun textPositionZuYKoordiante(textPosition: Int): Int {
        var y = textPosition / 21
        return y
    }

    fun koordinateZuTextPosition(x: Int, y: Int): Int {
        var position = y * 21 + x
        return position
    }
}