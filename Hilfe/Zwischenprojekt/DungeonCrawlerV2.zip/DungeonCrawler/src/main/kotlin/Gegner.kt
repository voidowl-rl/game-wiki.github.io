import kotlin.random.Random

class Gegner {
    var x: Int
    var y: Int

    constructor(x: Int, y: Int) {
        this.x = x
        this.y = y
    }

    fun istAufPosition(x: Int, y: Int): Boolean {
        var istDasMeinePosition = this.x == x && this.y == y
        return istDasMeinePosition
    }

    fun setzePosition(x: Int, y: Int) {
        this.x = x
        this.y = y
    }

    fun bewege(welt: ZeilenWelt) {
    }

    fun greifeAn(spieler: Spieler) {
    }
}