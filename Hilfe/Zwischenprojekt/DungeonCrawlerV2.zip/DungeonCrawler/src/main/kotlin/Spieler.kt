class Spieler {
    var x: Int
    var y: Int

    constructor(x: Int, y: Int) {
        this.x = x
        this.y = y
    }

    fun istAufPosition(x: Int, y: Int): Boolean {
        var istDasMeinePosition = this.x == x && this.y == y
        return istDasMeinePosition
    }

    fun setzePosition(x: Int, y: Int) {
        this.x = x
        this.y = y
    }

    fun greifeAn(gegner: Gegner) {
    }

    fun bewege(x: Int, y: Int, welt: ZeilenWelt) {
    }
}