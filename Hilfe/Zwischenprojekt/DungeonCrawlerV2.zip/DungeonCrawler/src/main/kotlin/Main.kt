import kotlin.random.Random

fun main() {
    var spiel = Spiel()
    spiel.starteSpiel()
}
