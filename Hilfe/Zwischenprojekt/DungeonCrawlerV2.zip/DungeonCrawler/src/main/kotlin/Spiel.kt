/**
 * Die Klasse Spiel dient der Verwaltung des laufenden Spiels. In ihr werden alle Elemente des Spiels initialisiert
 * und miteinander in Verknüpfung gesetzt. In ihr läuft die Spielschleife ab, d.h. eine potenzielle Endlosschleife
 * die das Spiel nur beendet wenn der Spieler das Spiel beendet oder gewonnen/verloren hat.
 */
class Spiel {
    var spielLaeuft: Boolean = false
    var stift = Stift()
    var welt: ZeilenWelt

    /**
     * Das Einlesen der Karte wird vorerst weggelassen
     * Stattdessen wird eine Karte als Text vorgegeben
     * Durch die Verwendung von drei Anführungszeichen kann ein mehrzeiliger String im Code definiert werden.
     */
    constructor() {
        var zeilen = """
        ####################
        #....~.............#
        #....~....1....a...#
        #...c~..2......b...#
        #..~~~~~~..........#
        #...........X......#
        #################### 
    """.trimIndent()

        var spieler = Spieler(0,0)
        var gegner1 = Gegner(0,0)
        var gegner2 = Gegner(0,0)
        var muenze1 = Muenze(0,0)
        var muenze2 = Muenze(0,0)
        var muenze3 = Muenze(0,0)

        welt = ZeilenWelt(zeilen, spieler, gegner1, gegner2, muenze1, muenze2, muenze3)
    }

    /**
     * Diese Funktion sollte auf einem Objekt der Klasse Spiel aufgerufen werden, um das Spiel zu starten.
     * Die While-Schleife erzeugt solange neue Züge, bis der Boolean spielLaeuft auf false gesetzt wird.
     * Sinnvolle Gründe hierfür können der Abbruch des Spiels sein (durch Spielereingabe) oder weil der Spieler
     * gewonnen oder verloren hat.
     */
    fun starteSpiel() {
        spielLaeuft = true

        while (spielLaeuft) {
            welt.zeichneWelt(stift)
            stift.schreibe("Was möchtest du tun:")
            stift.neueZeile()
            verarbeiteSpielerEingabe()
            verarbeiteGegnerAktionen()
            beendeZug()
        }
    }

    /**
     * In dieser Funktion wird der Zug des Gegners ausgeführt.
     */
    fun verarbeiteGegnerAktionen() {

    }

    /**
     * In dieser Funktion wird der Zug des Spielers ausgeführt.
     */
    fun verarbeiteSpielerEingabe() {
        print("> ")
        var eingabe = readln()

        if (eingabe == "ende") {
            spielLaeuft = false
        }
    }

    /**
     * Diese Funktion beendet den aktuellen Zug. Sie sollte um mögliche Ereignisse erweitert werden,
     * die am Ende des Zugs vorliegen könnten.
     */
    fun beendeZug() {
        stift.neueZeile()
        stift.schreibe("-- ENDE DES ZUGS --")
        stift.neueZeile()
    }
}