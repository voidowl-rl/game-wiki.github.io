/**
 * Die Klasse Stift erfüllt den Zweck Text auf der Konsole farbig oder in normaler Farbe
 * auszugeben. Um nicht zwischen dem Stift und zusätzlichen println()-Kommandos hin- und herspringen
 * zu müssen, besitzt die Klasse ebenfalls die Möglichkeit eine neue Zeile auf der Konsole anzulegen.
 */
class Stift {
    /** In diesen Variablen sind Werte gespeichert, die Konsolen als Befehl interpretieren die Textfarbe zu ändern */
    var kommandoRot = "\u001b[31m"
    var kommandoBlau = "\u001b[34m"
    var kommandoGruen = "\u001b[32m"
    var kommandoGelb = "\u001b[33m"
    var kommandoSchwarz = "\u001b[30m"
    var kommandoNormal = "\u001b[0m"

    /**
     * Über diese Funktion kann beliebiger Text in normaler Textfarbe ausgegeben werden.
     */
    fun schreibe(text: Any) {
        print(text)
    }

    /**
     * Über diese Funktion kann beliebiger Text in roter Textfarbe ausgegeben werden.
     */
    fun schreibeRot(text: Any) {
        print(kommandoRot + text + kommandoNormal)
    }

    /**
     * Über diese Funktion kann beliebiger Text in gelber Textfarbe ausgegeben werden.
     */
    fun schreibeGelb(text: Any) {
        print(kommandoGelb + text + kommandoNormal)
    }

    /**
     * Über diese Funktion kann beliebiger Text in schwarzer Textfarbe ausgegeben werden.
     */
    fun schreibeSchwarz(text: Any) {
        print(kommandoSchwarz + text + kommandoNormal)
    }

    /**
     * Über diese Funktion kann beliebiger Text in blauer Textfarbe ausgegeben werden.
     */
    fun schreibeBlau(text: Any) {
        print(kommandoBlau + text + kommandoNormal)
    }

    /**
     * Über diese Funktion kann beliebiger Text in grüner Textfarbe ausgegeben werden.
     */
    fun schreibeGruen(text: Any) {
        print(kommandoGruen + text + kommandoNormal)
    }

    /**
     * Mit dieser Funktion wird ein Zeilenumbruch ausgegeben.
     */
    fun neueZeile() {
        println()
    }
}