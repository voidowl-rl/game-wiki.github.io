class Spieler {
    fun greifeAn(gegner: Gegner) {
    }

    fun bewege(x: Int, y: Int, welt: ZeilenWelt) {
    }
}