/**
 * Die Zeilenwelt verwaltet die unbeweglichen Teile der Welt und hat außerdem zusätzliche Funktionen, um
 * zu überprüfen, ob ein Feld begehbar ist oder nicht. Eine Welt besteht immer aus einer exakt
 * 20x7 großen Welt, einem Spieler und zwei Gegnern.
 */
class ZeilenWelt {
    var zeile1 = ""
    var zeile2 = ""
    var zeile3 = ""
    var zeile4 = ""
    var zeile5 = ""
    var zeile6 = ""
    var zeile7 = ""

    var spieler: Spieler
    var gegner1: Gegner
    var gegner2: Gegner

    constructor(alleZeilen: String, spieler: Spieler, gegner1: Gegner, gegner2: Gegner) {
        this.spieler = spieler
        this.gegner1 = gegner1
        this.gegner2 = gegner2

        // Diese Schleife wird genau so oft ausgeführt, wird der String Zeilen Zeichen hat.
        // Der aktuelle Wert ist im Schleifenblock in der Variable position verfügbar.
        for (position in 0..alleZeilen.length - 1) {
            // Über die Syntax zeilen[<Variable oder Wert>] kann auf ein einzelnes Zeichen
            // eines Strings zugegriffen werden.
            // Der Variablentyp eines Zeichens wird CHAR genannt.
            var aktuellesZeichen: Char = alleZeilen[position]

            // Erweitere diese Funktion, sodass in die Variablen zeile1 bis zeile7 die entsprechenden
            // Zeilen abgespeichert werden. Dies hilft dir später.
            // Vergiss nicht, Gegner, Spieler und Münzen in eigene Objekte zu überführen und auf der Karte
            // an ihrer statt einfach ein leeres Feld zu platzieren (.).

            // Folgendes ist zum Beispiel möglich
            // var neueZeile: String = ""
            // neueZeile = neueZeile + aktuellesZeichen

            // Eine andere Möglichkeit die einzelnen Zeilen zu trennen besteht über die Methode
            // substring: https://kotlintutorial.de/standardfunktionen-fuer-strings/
        }
    }

    /**
     * Diese Funktion gibt die Welt auf der Konsole auf. Für jedes Feld wird vor der Ausgabe überprüft,
     * ob nicht stattdessen ein Gegner, eine Münze oder ein Spieler dargestellt werden muss.
     */
    fun zeichneWelt(stift: Stift) {

    }

    /**
     * Diese Funktion überprüft, ob ein Feld mit den Koordinaten x und y begehbar ist, oder ob es blockiert ist.
     */
    fun istBegehbar(x: Int, y: Int): Boolean {
        return true
    }

    /**
     * Dies ist eine Hilfsfunktion, die für eine Zeilennummer die entsprechende Zeilenvariable zurück gibt.
     */
    fun zeilenNummerZuZeile(zeilennummer: Int): String {
        if (zeilennummer == 0) return zeile1
        else if (zeilennummer == 1) return zeile2
        else if (zeilennummer == 2) return zeile3
        else if (zeilennummer == 3) return zeile4
        else if (zeilennummer == 4) return zeile5
        else if (zeilennummer == 5) return zeile6
        return zeile7
    }
}