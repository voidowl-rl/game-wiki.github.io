import kotlin.random.Random

class Gegner {
    fun bewege(welt: ZeilenWelt) {
    }

    fun greifeAn(spieler: Spieler) {
    }
}